// Execute this code snippet in your Chrome Developer Tools

navigator.mediaDevices.enumerateDevices( function(device) {
    for(var count = 0; count < devices.length; count++) {
        console.log("device " + (count + 1) + " info:");
        console.log("ID is: " + devices [count].id);

        if(devices [count].label == "")
        {
          console.log("Name of the device is: unknown");
        }
        else
        {
          console.log("Name of the device is: " + devic-es[count].label);
        }
        
        console.log("Kind of device: " + devices[count].kind);

        if(devices[count].facing == "")
        {
          console.log("device facing: unknown");
        }
        else
        {
          console.log("device facing: " + devices[count].facing);
        }
    }
}).then( console.table );