var Server = require("socket.io");
var io = new Server({path: "/websocket"});
io.listen(3000);

io.on("connection", function(socket) {
    socket.send( "Hi, from server" );
    socket.on( "message", function( message ) {
        console.log( message );
    } );
    socket.on( "disconnect", function() {
        console.log( "User Disconnected" );
    } );
    socket.emit( "custom-event", "parameter1", "parameter2" );
    socket.on( "custom-event", function ( parameter1, parameter2) {
        console.log(parameter1, parameter2);
    } );
} );
