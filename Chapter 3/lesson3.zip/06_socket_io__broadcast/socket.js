var Server = require("socket.io");
var io = new Server({path: "/websocket"});
io.listen(3000);

io.origins("localhost:8080");

io.on( "connection", function(socket) {
    socket.send( "Hi, from server" );
    socket.on( "message", function( message ) {
        console.log( message );
    } );
    socket.on( "disconnect", function() {
        console.log( "User Disconnected" );
    } );
    socket.emit( "custom-event", "parameter1", "parameter2" );
    socket.on( "custom-event", function ( parameter1, parameter2) {
        console.log(parameter1, parameter2);
    } );
} );

var nsp = io.of( "/custom-namespace" );
nsp.on("connection", function( socket ) {
    socket.send( "Hi, from custom-namespace" );
    socket.on( "message", function(message) {
        console.log( message );
    } );
    socket.on( "disconnect", function() {
        console.log( "User Disconnected" );
    } );
    socket.on( "custom-event", function( parameter1, parameter2 ) {
        console.log(parameter1, parameter2);
    } );
    socket.emit("custom-event", "parameter1", "parameter2");
} );

setInterval( function() {
    //sending message and custom-event-2 to all clients of default namespace
    io.emit( "custom-event-2" );
    io.send( "Hello Everyone. What's up!!!" );
    //sending message and custom-event-2 to all clients of /customnamespace namespace
    nsp.emit( "custom-event-2" );
    nsp.send( "Hello Everyone. What's up!!!" );
}, 5000 );
