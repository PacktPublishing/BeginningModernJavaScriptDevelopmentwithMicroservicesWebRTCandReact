var seneca = require("seneca")();

// Create actions
seneca.add( {
        role: "accountManagement", 
        cmd: "login"
    }, function(msg, respond) {
        respond( null, {
            message: `Logging in ${msg.username}`
        } );
    }
);

seneca.add( {
        role: "accountManagement", 
        cmd: "register"
    }, function(msg, respond) {
        respond( null, {
            message: `Registering  ${msg.username}`
        } );        
    }
);

// Invoke actions
seneca.act( {
        role: "accountManagement", 
        cmd: "register", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
         if (error) return console.error(error);
         console.log("register response: ", response.message );
    } 
);

seneca.act( {
        role: "accountManagement", 
        cmd: "login", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
        if (error) return console.error(error);
        console.log("login response: ", response.message );
    }
);
