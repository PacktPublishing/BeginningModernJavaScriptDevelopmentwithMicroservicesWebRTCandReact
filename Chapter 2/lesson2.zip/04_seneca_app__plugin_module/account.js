
module.exports = function account( options ) {
    this.add( { init: "account" }, function( pluginInfo, respond ) {
        console.log( options.message );
        respond();
    } );
    this.add(
        { role: "accountManagement", cmd: "login" },
        function( msg, respond ) {
            respond( null, {
                message: `Logging in ${msg.username}`
            } );
        }
    );
    this.add(
       { role: "accountManagement", cmd: "register"},
       function( msg, respond ) {
            respond( null, {
                message: `Registering  ${msg.username}`
            } );
       }
    );

    return "account";
}