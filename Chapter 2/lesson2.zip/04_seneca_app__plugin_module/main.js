var seneca = require("seneca")();

seneca.use("./account.js", {message: "Plugin Added"});

// Invoke actions
seneca.act( {
        role: "accountManagement", 
        cmd: "register", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
         if (error) return console.error(error);
         console.log("register response: ", response.message );
    } 
);

seneca.act( {
        role: "accountManagement", 
        cmd: "login", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
        if (error) return console.error(error);
        console.log("login response: ", response.message );
    }
);
