
module.exports = function account( options ) {
    this.add( { init: "account" }, function( pluginInfo, respond ) {
        console.log( options.message );
        respond();
    } );
    this.add(
        { role: "accountManagement", cmd: "login" },
        function( args, respond ) {
            var accounts = this.make("accounts");
            var queryPattern = {
                username: args.username,
                password: args.password
            };
            accounts.list$( queryPattern, function( error, entity ) {
                if( error ) return respond( error );
                var response = entity.length != 0;
                respond( null, { value: response } );
            } );
        }
    );
    this.add(
        { role: "accountManagement", cmd: "register"},
        function( args, respond ) {
            var accounts = this.make("accounts");
            var queryPattern = { username: args.username };
            accounts.list$( queryPattern, function( error, entity ) {
                if( error ) return respond(error);
                if( entity.length == 0 ) {
                    var data = accounts.data$( {
                         username: args.username, 
                         password: args.password
                    } );
                    data.save$(function(error, entity) {
                        if(error) return respond(error);
                        respond(null, {value: true});
                    });
                } else {
                    respond(null, {value: false});
                }
            });
        }
    );

    return "account";
}