var seneca = require("seneca")();

// Create plugins
function account( options ) {
    this.add( { init: "account" }, function( pluginInfo, respond ) {
        console.log( options.message );
        respond();
    } );
    this.add(
        { role: "accountManagement", cmd: "login" },
        function( msg, respond ) {
            respond( null, {
                message: `Logging in ${msg.username}`
            } );
        }
    );
    this.add(
       { role: "accountManagement", cmd: "register"},
       function( msg, respond ) {
            respond( null, {
                message: `Registering  ${msg.username}`
            } );
       }
    );
}

seneca.use( account, { message: "Plugin Added" } );


// Invoke actions
seneca.act( {
        role: "accountManagement", 
        cmd: "register", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
         if (error) return console.error(error);
         console.log("register response: ", response.message );
    } 
);

seneca.act( {
        role: "accountManagement", 
        cmd: "login", 
        username: "zsolt", 
        password: "zsoltnagy.eu"
    }, function(error, response) {
        if (error) return console.error(error);
        console.log("login response: ", response.message );
    }
);
