
var myButton_click_stream = 
    $("#myButton")
        .asEventStream("click")
        .filter( function( e ) {
            return e.shiftKey === true;
        } );
myButton_click_stream.onValue( function( e ) {
    console.log( e );
    console.log( "Button Clicked" );
} );


var button_click_counter = 
    myButton_click_stream.scan( 0, function( value, e ) {
        return ++value;
    } );
button_click_counter.onValue( function( value ) {
    console.log(`Button is clicked ${value} number of times`);
} );

var button_click_time = 
    button_click_counter.scan( {}, function( value, count ) {
        return {
            time: Date.now(), 
            clicks: count
        };
    } ).map( function( value ) {
        var date = new Date(value.time);
        return (date).getHours() + ":" + (date).getMinutes();
    } );


var merged_property = 
    Bacon.mergeAll( [button_click_counter, button_click_time ] );
merged_property.onValue( function( e ) {
    console.log( e );
} );

// ----------
// URL field:
// ----------

var enter_key_click_stream = 
    $( "#url" )
        .asEventStream("keyup")
        .filter( function( e ) {
            return e.keyCode == 13;
        } );
var url = enter_key_click_stream.scan( "", function( value, e ) {
    return e.currentTarget.value;
} );

var response = url.flatMap( function(value) {
    try {
        return Bacon.retry( {
            source: function() { 
                return Bacon.fromPromise($.ajax({url:value})); 
            },
            retries: 5,
            isRetryable: function(error) { 
                return error.status !== 404;
            },
            delay: function(context) { return 2000; }
        } );
    } catch(e) {
        return new Bacon.Error(e);
    }
} ).toProperty();



response.onError( function( error ) {
    console.log( "An error occured while fetching the page", error );
} );

stream = Bacon.fromArray([1,2,3,4]).flatMap(function(x) {
    if (x > 2) { 
        return new Bacon.Error("too large");
    } else { 
        return x;
    }
} );

function isNonCriticalError() { return true; }
function handleNonCriticalError() { 
    console.log( 'Non critical error has been handled.' ); 
}

stream2 = stream.flatMapError(function(error) {
    return isNonCriticalError(error) ? 
           handleNonCriticalError(error) : 
           new Bacon.Error(error);
} );


var script_start_time = Bacon.constant(
    Date.now()
).map(function(value){
        var date = new Date(value);
        return (date).getHours() + ":" + 
               (date).getMinutes() + ":" +
               (date).getSeconds();
});
script_start_time.onValue( function(value) {
    console.log("This script started running at : " + value);
});


 script_start_time.onEnd(function(){
    console.log("Script start time has been successfully calculated and logged");
});

//////////////////////////
// Lazy Evaluation type 1
//////////////////////////

var myButton_click_stream1 =
    $("#myButton").asEventStream("click").map(function(event) {
        console.log(event);
        return event;
    });
myButton_click_stream1.onValue(function(event) {
    console.log(event);
    return event;
});


/*
// Execute the following code in the developer tools:

var myBus_1 = new Bacon.Bus();
var myBus_2 = new Bacon.Bus();
var myProperty_1 = myBus_1.map(function(event){
 console.log("Executing 1");
 return event;
}).toProperty();
var myStream_1 = myProperty_1.sampledBy(myBus_2);
myStream_1.onValue(function(event){
 console.log("Logged", event);
})
myBus_1.push(1);

myBus_1.push(2); 
myBus_2.push();



*/