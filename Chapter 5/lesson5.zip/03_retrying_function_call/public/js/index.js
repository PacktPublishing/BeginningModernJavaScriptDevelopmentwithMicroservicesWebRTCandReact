
var myButton_click_stream = 
    $("#myButton")
        .asEventStream("click")
        .filter( function( e ) {
            return e.shiftKey === true;
        } );
myButton_click_stream.onValue( function( e ) {
    console.log( e );
    console.log( "Button Clicked" );
} );


var button_click_counter = 
    myButton_click_stream.scan( 0, function( value, e ) {
        return ++value;
    } );
button_click_counter.onValue( function( value ) {
    console.log(`Button is clicked ${value} number of times`);
} );

var button_click_time = 
    button_click_counter.scan( {}, function( value, count ) {
        return {
            time: Date.now(), 
            clicks: count
        };
    } ).map( function( value ) {
        var date = new Date(value.time);
        return (date).getHours() + ":" + (date).getMinutes();
    } );


var merged_property = 
    Bacon.mergeAll( [button_click_counter, button_click_time ] );
merged_property.onValue( function( e ) {
    console.log( e );
} );

// ----------
// URL field:
// ----------

var enter_key_click_stream = 
    $( "#url" )
        .asEventStream("keyup")
        .filter( function( e ) {
            return e.keyCode == 13;
        } );
var url = enter_key_click_stream.scan( "", function( value, e ) {
    return e.currentTarget.value;
} );

var response = url.flatMap( function(value) {
    return Bacon.retry({
        source: function() { 
            return Bacon.fromPromise( $.ajax( {url:value} ) ); 
        },
        retries: 5,
        isRetryable: function (error) { 
            return error.status !== 404;
        },
        delay: function(context) { return 2000; } //just use the same delay always
 });
}).toProperty();


response.onError( function( error ) {
    console.log( "An error occured while fetching the page", error );
} );

stream = Bacon.fromArray([1,2,3,4]).flatMap(function(x) {
    if (x > 2) { 
        return new Bacon.Error("too large");
    } else { 
        return x;
    }
} );

function isNonCriticalError() { return true; }
function handleNonCriticalError() { 
    console.log( 'Non critical error has been handled.' ); 
}

stream2 = stream.flatMapError(function(error) {
    return isNonCriticalError(error) ? 
           handleNonCriticalError(error) : 
           new Bacon.Error(error);
} );
