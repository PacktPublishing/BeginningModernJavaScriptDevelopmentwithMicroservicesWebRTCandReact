
var myButton_click_stream = 
    $("#myButton")
        .asEventStream("click")
        .filter( function( e ) {
            return e.shiftKey === true;
        } );
myButton_click_stream.onValue( function( e ) {
    console.log( e );
    console.log( "Button Clicked" );
} );


var button_click_counter = 
    myButton_click_stream.scan( 0, function( value, e ) {
        return ++value;
    } );
button_click_counter.onValue( function( value ) {
    console.log(`Button is clicked ${value} number of times`);
} );

var button_click_time = 
    button_click_counter.scan( {}, function( value, count ) {
        return {
            time: Date.now(), 
            clicks: count
        };
    } ).map( function( value ) {
        var date = new Date(value.time);
        return (date).getHours() + ":" + (date).getMinutes();
    } );


var merged_property = 
    Bacon.mergeAll( [button_click_counter, button_click_time ] );
merged_property.onValue( function( e ) {
    console.log( e );
} );

// ----------
// URL field:
// ----------

var enter_key_click_stream = 
    $( "#url" )
        .asEventStream("keyup")
        .filter( function( e ) {
            return e.keyCode == 13;
        } );
var url = enter_key_click_stream.scan( "", function( value, e ) {
    return e.currentTarget.value;
} );

var response = url.flatMap( function( value ) {
    return Bacon.fromPromise( $.ajax( {url:value} ) );
} ).toProperty();
response.onValue( function( value ) {
    console.log( value );
} );

response.onError( function( error ) {
    console.log( "An error occured while fetching the page", error );
} );